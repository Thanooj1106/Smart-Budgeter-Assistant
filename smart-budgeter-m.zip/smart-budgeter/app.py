from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import os
from authlib.integrations.flask_client import OAuth
from ml_engine import predict_category, forecast_next_month, generate_suggestions, summarize_expenses_by_category
from models import db, User, Transaction, init_db

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

init_db(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

# OAuth setup
oauth = OAuth(app)
oauth.register(
    name='google',
    client_id=os.environ.get('GOOGLE_CLIENT_ID', 'your-google-client-id'),
    client_secret=os.environ.get('GOOGLE_CLIENT_SECRET', 'your-google-client-secret'),
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    access_token_url='https://oauth2.googleapis.com/token',
    api_base_url='https://www.googleapis.com/oauth2/v1/',
    userinfo_endpoint='https://openidconnect.googleapis.com/v1/userinfo',
    client_kwargs={'scope': 'openid email profile'}
)
oauth.register(
    name='github',
    client_id=os.environ.get('GITHUB_CLIENT_ID', 'your-github-client-id'),
    client_secret=os.environ.get('GITHUB_CLIENT_SECRET', 'your-github-client-secret'),
    access_token_url='https://github.com/login/oauth/access_token',
    authorize_url='https://github.com/login/oauth/authorize',
    api_base_url='https://api.github.com/',
    client_kwargs={'scope': 'user:email'}
)
oauth.register(
    name='apple',
    client_id=os.environ.get('APPLE_CLIENT_ID', 'your-apple-client-id'),
    client_secret=os.environ.get('APPLE_CLIENT_SECRET', 'your-apple-client-secret'),
    server_metadata_url='https://appleid.apple.com/.well-known/openid_configuration',
    client_kwargs={'scope': 'name email'}
)
oauth.register(
    name='twitter',
    client_id=os.environ.get('TWITTER_CLIENT_ID', 'your-twitter-client-id'),
    client_secret=os.environ.get('TWITTER_CLIENT_SECRET', 'your-twitter-client-secret'),
    access_token_url='https://api.twitter.com/2/oauth2/token',
    authorize_url='https://twitter.com/i/oauth2/authorize',
    api_base_url='https://api.twitter.com/2/',
    client_kwargs={'scope': 'tweet.read users.read'}
)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html', user=current_user if current_user.is_authenticated else None)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return redirect(url_for('register'))
        user = User(name=name, email=email, password_hash=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        login_user(user)
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash('Invalid credentials', 'danger')
            return redirect(url_for('login'))
        login_user(user)
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    # fetch transactions for current user
    txs = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.date.desc()).all()
    balance = sum(t.amount if t.type == 'income' else -t.amount for t in txs)
    by_category = summarize_expenses_by_category(txs)
    suggestions = generate_suggestions(txs, current_user.savings_goal or 0)
    forecast = forecast_next_month(txs)
    return render_template('dashboard.html', transactions=txs, balance=balance, by_category=by_category, suggestions=suggestions, forecast=forecast, savings_goal=current_user.savings_goal, now=datetime.utcnow())

@app.route('/add', methods=['POST'])
@login_required
def add_transaction():
    amount = float(request.form['amount'])
    ttype = request.form['type']  # 'income' or 'expense'
    desc = request.form.get('description','').strip()
    date_str = request.form.get('date')
    if date_str:
        d = datetime.fromisoformat(date_str)
    else:
        d = datetime.utcnow()
    category = None
    if ttype == 'expense':
        category = predict_category(desc, amount)
    tx = Transaction(user_id=current_user.id, amount=amount, type=ttype, description=desc, category=category, date=d)
    db.session.add(tx)
    db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/set_goal', methods=['POST'])
@login_required
def set_goal():
    goal_str = request.form.get('goal', '').strip()
    if goal_str:
        try:
            goal = float(goal_str)
        except ValueError:
            flash('Invalid savings goal amount', 'danger')
            return redirect(url_for('dashboard'))
    else:
        goal = 0.0
    current_user.savings_goal = goal
    db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/ai_assistant')
@login_required
def ai_assistant():
    # Get user's transaction data
    txs = Transaction.query.filter_by(user_id=current_user.id).all()
    balance = sum(t.amount if t.type == 'income' else -t.amount for t in txs)
    by_category = summarize_expenses_by_category(txs)
    suggestions = generate_suggestions(txs, current_user.savings_goal or 0)
    forecast = forecast_next_month(txs)

    # Generate additional AI suggestions
    ai_suggestions = []

    # Expense reduction suggestions
    if by_category:
        top_expense_category = max(by_category.items(), key=lambda x: x[1])
        ai_suggestions.append(f"Consider reducing spending in {top_expense_category[0]} by 20% to save ${top_expense_category[1] * 0.2:.2f} monthly.")

    # Income-based suggestions
    total_income = sum(t.amount for t in txs if t.type == 'income')
    if total_income > 0:
        ai_suggestions.append(f"With your income of ${total_income:.2f}, you could save 20% (${total_income * 0.2:.2f}) monthly.")
        ai_suggestions.append(f"Emergency fund goal: Save 3-6 months of expenses (${balance * 0.1:.2f} monthly).")

    # Suggested goals
    suggested_goals = [
        {"amount": 500, "description": "Emergency Fund Starter"},
        {"amount": 1000, "description": "Vacation Savings"},
        {"amount": 2000, "description": "New Gadget Fund"},
        {"amount": total_income * 0.1 if total_income > 0 else 100, "description": "10% of Monthly Income"}
    ]

    return render_template('ai_assistant.html',
                         suggestions=suggestions,
                         ai_suggestions=ai_suggestions,
                         suggested_goals=suggested_goals,
                         balance=balance,
                         by_category=by_category,
                         now=datetime.utcnow())

@app.route('/set_suggested_goal/<float:goal_amount>')
@login_required
def set_suggested_goal(goal_amount):
    current_user.savings_goal = goal_amount
    db.session.commit()
    flash(f'Savings goal set to ${goal_amount:.2f}!', 'success')
    return redirect(url_for('ai_assistant'))

@app.route('/profile')
@login_required
def profile():
    # Get user's statistics
    txs = Transaction.query.filter_by(user_id=current_user.id).all()
    total_income = sum(t.amount for t in txs if t.type == 'income')
    total_expenses = sum(t.amount for t in txs if t.type == 'expense')
    net_savings = total_income - total_expenses

    # Calculate monthly averages
    from datetime import datetime, timedelta
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    recent_txs = [t for t in txs if t.date >= thirty_days_ago]
    monthly_income = sum(t.amount for t in recent_txs if t.type == 'income')
    monthly_expenses = sum(t.amount for t in recent_txs if t.type == 'expense')

    return render_template('profile.html',
                         total_income=total_income,
                         total_expenses=total_expenses,
                         net_savings=net_savings,
                         monthly_income=monthly_income,
                         monthly_expenses=monthly_expenses,
                         transaction_count=len(txs),
                         member_since=current_user.created_at)

@app.route('/reports')
@login_required
def reports():
    # Get user's transaction data for reports
    txs = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.date).all()

    # Monthly breakdown
    from collections import defaultdict
    monthly_data = defaultdict(lambda: {'income': 0, 'expense': 0})
    for tx in txs:
        month_key = tx.date.strftime('%Y-%m')
        monthly_data[month_key][tx.type] += tx.amount

    # Category breakdown
    category_data = defaultdict(float)
    for tx in txs:
        if tx.type == 'expense' and tx.category:
            category_data[tx.category] += tx.amount

    return render_template('reports.html',
                         monthly_data=dict(monthly_data),
                         category_data=dict(category_data),
                         transactions=txs)

@app.route('/add_transaction')
@login_required
def add_transaction_page():
    return render_template('add_transaction.html', now=datetime.utcnow())

# API endpoints for frontend JS (optional)
@app.route('/api/summary')
@login_required
def api_summary():
    txs = Transaction.query.filter_by(user_id=current_user.id).all()
    balance = sum(t.amount if t.type == 'income' else -t.amount for t in txs)
    by_category = summarize_expenses_by_category(txs)
    forecast = forecast_next_month(txs)
    suggestions = generate_suggestions(txs, current_user.savings_goal or 0)
    return jsonify({'balance': balance, 'by_category': by_category, 'forecast': forecast, 'suggestions': suggestions})

# OAuth routes
@app.route('/login/<provider>')
def oauth_login(provider):
    if provider not in ['google', 'github', 'apple', 'twitter']:
        flash('Invalid provider', 'danger')
        return redirect(url_for('login'))

    # Check if OAuth credentials are configured
    client_id = os.environ.get(f'{provider.upper()}_CLIENT_ID')
    client_secret = os.environ.get(f'{provider.upper()}_CLIENT_SECRET')
    if not client_id or client_id.startswith('your-') or not client_secret or client_secret.startswith('your-'):
        flash(f'{provider.title()} OAuth is not configured. Please set up OAuth credentials.', 'warning')
        return redirect(url_for('login'))

    redirect_uri = url_for('oauth_callback', provider=provider, _external=True)
    return oauth.create_client(provider).authorize_redirect(redirect_uri)

@app.route('/login/<provider>/callback')
def oauth_callback(provider):
    if provider not in ['google', 'github', 'apple', 'twitter']:
        flash('Invalid provider', 'danger')
        return redirect(url_for('login'))

    try:
        token = oauth.create_client(provider).authorize_access_token()
        if provider == 'google':
            user_info = oauth.google.userinfo()
            email = user_info['email']
            name = user_info['name']
        elif provider == 'github':
            resp = oauth.github.get('user')
            user_info = resp.json()
            email = user_info['email']
            name = user_info['name']
        elif provider == 'apple':
            # Apple OAuth handling (simplified)
            user_info = token.get('userinfo', {})
            email = user_info.get('email')
            name = user_info.get('name', 'Apple User')
        elif provider == 'twitter':
            # Twitter OAuth handling (simplified)
            resp = oauth.twitter.get('users/me')
            user_info = resp.json()['data']
            email = f"{user_info['username']}@twitter.local"  # Twitter doesn't provide email
            name = user_info['name']

        # Check if user exists, if not create
        user = User.query.filter_by(email=email).first()
        if not user:
            user = User(name=name, email=email, password_hash=generate_password_hash('oauth_user'))
            db.session.add(user)
            db.session.commit()

        login_user(user)
        return redirect(url_for('dashboard'))
    except Exception as e:
        flash(f'OAuth login failed: {str(e)}', 'danger')
        return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
