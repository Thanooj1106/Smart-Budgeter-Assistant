# Simple, dependency-free ML-like helpers for demo purposes.
# Replace with a trained sklearn model for production.
import re
from collections import defaultdict
from datetime import datetime
import math

# keyword-based mapping
CATEGORY_KEYWORDS = {
    'food': ['restaurant','dinner','lunch','breakfast','cafe','food','pizza','burger','meal','grocer','grocery'],
    'transport': ['uber','ola','taxi','bus','train','metro','fuel','petrol','diesel','transport'],
    'entertainment': ['movie','netflix','prime','concert','game','pub','bar','entertainment'],
    'shopping': ['amazon','flipkart','shirt','pants','dress','clothes','shopping'],
    'bills': ['electricity','water','internet','mobile','bill','rent'],
    'health': ['doctor','hospital','pharmacy','medicine','gym','health'],
    'education': ['course','school','tuition','books','education','course'],
    'other': []
}

def predict_category(description, amount):
    desc = (description or '').lower()
    # keyword matching
    scores = {}
    for cat, kws in CATEGORY_KEYWORDS.items():
        scores[cat] = sum(desc.count(k) for k in kws)
    # fallback to amount-based heuristics
    if all(v==0 for v in scores.values()):
        if amount > 5000:
            return 'shopping'
        if amount > 2000:
            return 'bills'
        return 'other'
    # pick highest score, tie-breaker by longest keyword hits
    best = max(scores.items(), key=lambda x: (x[1], len(x[0])))[0]
    return best

def summarize_expenses_by_category(transactions):
    res = defaultdict(float)
    for t in transactions:
        if t.type == 'expense':
            cat = t.category or 'other'
            res[cat] += float(t.amount)
    return dict(res)

def forecast_next_month(transactions):
    # Very simple forecasting: take monthly totals for last 3 months (by month) and linear extrapolation.
    monthly = {}
    for t in transactions:
        m = t.date.strftime('%Y-%m')
        monthly.setdefault(m, 0.0)
        monthly[m] += float(t.amount) if t.type=='expense' else -float(t.amount)
    # sort months
    months = sorted(monthly.items())
    if len(months) < 2:
        return {'forecast_next_month': sum(monthly.values()) if monthly else 0.0}
    # convert to numbers and do linear regression y = a + b*x
    xs = list(range(len(months)))
    ys = [v for _,v in months]
    n = len(xs)
    x_mean = sum(xs)/n
    y_mean = sum(ys)/n
    num = sum((xs[i]-x_mean)*(ys[i]-y_mean) for i in range(n))
    den = sum((xs[i]-x_mean)**2 for i in range(n)) or 1
    b = num/den
    a = y_mean - b*x_mean
    next_x = n
    pred = a + b*next_x
    return {'forecast_next_month': round(pred,2)}

def generate_savings_estimate(transactions):
    # simple idea: how much could be saved by cutting discretionary categories by 10%
    by_cat = summarize_expenses_by_category(transactions)
    discretionary = 0.0
    for c in ['entertainment','shopping','food']:
        discretionary += by_cat.get(c,0.0)
    save_est = discretionary * 0.10
    return round(save_est,2)

def generate_suggestions(transactions, savings_goal=0):
    by_cat = summarize_expenses_by_category(transactions)
    suggestions = []
    # overspending flag: category > 30% of total expenses
    total_expense = sum(by_cat.values()) or 1.0
    for cat, amt in by_cat.items():
        if amt / total_expense > 0.30:
            suggestions.append(f"You're spending {round((amt/total_expense)*100,1)}% on {cat}. Consider reducing it.")
    # savings opportunity
    est = generate_savings_estimate(transactions)
    if est > 0:
        suggestions.append(f'You can potentially save ₹{est} per month by cutting discretionary spending by 10%.')
    # goal recommendation
    if savings_goal and est>0:
        months = math.ceil(savings_goal / est) if est>0 else None
        if months:
            suggestions.append(f'At this saving rate you can reach your goal of ₹{savings_goal} in about {months} months.')
    return suggestions
