# Smart Budgeter (Full project)

**What this is**
- A full-stack Flask project (Python) + SQLite that lets users register/login, add income & expenses, auto-categorize expenses using a simple built-in ML-like classifier (keyword-based), shows dashboard with totals, expenses-by-category, savings goal, AI suggestions, and a basic forecast for next month.

**Included**
- Backend: Flask app (`app.py`, `models.py`, `ml_engine.py`, `auth_utils.py`)
- Frontend: Jinja2 templates + Bootstrap in `templates/` and minimal JS in `static/`
- Database: SQLite (`app.db`) will be created when you run the app.
- `requirements.txt`

**Notes & Caveats**
- OAuth providers (Google, GitHub, Apple, Twitter/X) are scaffolded with placeholders. You must register apps with providers and add credentials to environment variables or `.env` as instructed.
- The expense categorization model provided is a simple keyword-based classifier for portability. Replace `ml_engine.py` with a trained sklearn model if you want stronger ML categorization.
- This repository is ready to run locally. See instructions below.

## Quick start (local)
1. Create and activate a Python 3.10+ virtualenv:
   ```bash
   python -m venv venv
   source venv/bin/activate   # on Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Set environment variables (example):
   ```bash
   export FLASK_APP=app.py
   export FLASK_ENV=development
   # For OAuth: add provider credentials (see below)
   ```
3. Initialize DB and run (first run creates `app.db` automatically):
   ```bash
   flask run
   ```
4. Open `http://127.0.0.1:5000` in your browser.

## OAuth configuration (optional)
- Add client IDs/Secrets for Google, GitHub, Apple, Twitter/X to environment variables before enabling them in the app.
- The code contains `OAUTH_*` placeholders in `auth_utils.py`. Use Authlib or Flask-Dance to wire providers in production.

## File structure
- app.py                 - Main Flask app (routes)
- models.py              - SQLAlchemy models (User, Transaction)
- ml_engine.py           - Simple categorizer + forecast + suggestions
- auth_utils.py          - Helper functions for OAuth placeholders
- templates/             - HTML templates
- static/                - CSS / JS assets
- requirements.txt       - Python dependencies
- README.md
