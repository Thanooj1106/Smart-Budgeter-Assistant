# Placeholder helpers for OAuth provider configuration.
# For production, integrate Authlib or Flask-Dance and provide client IDs/secrets.
import os

def get_oauth_providers():
    # return dict of enabled providers (placeholders)
    return {
        'google': bool(os.environ.get('OAUTH_GOOGLE_CLIENT_ID')),
        'github': bool(os.environ.get('OAUTH_GITHUB_CLIENT_ID')),
        'apple': bool(os.environ.get('OAUTH_APPLE_CLIENT_ID')),
        'twitter': bool(os.environ.get('OAUTH_TWITTER_CLIENT_ID')),
    }
